import os
import json
import hashlib
from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
import re
import uuid
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, static_folder='.', static_url_path='')
app.config['SECRET_KEY'] = 'secret!'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024 
socketio = SocketIO(app, cors_allowed_origins="*")

USERS_FILE = 'users.json'

def load_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_users():
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

users = load_users()
messages_db = {"global": []} 
voice_users = {} # Tracks sid -> user info for WebRTC

# Add your specific filtered words here
BAD_WORDS = ["fuck", "shit", "bitch", "ass", "crap", "damn", "insert_first_word_here", "insert_second_word_here"] 

def censor_text(text):
    if not text:
        return text
    for word in BAD_WORDS:
        pattern = re.compile(re.escape(word), re.IGNORECASE)
        text = pattern.sub(lambda m: '*' * len(m.group()), text)
    return text

def get_dm_room(u1, u2):
    return "dm_" + "_".join(sorted([u1, u2]))

# Helper function to find a user regardless of uppercase/lowercase
def get_exact_username(requested_username):
    if not requested_username:
        return None
    for existing_user in users:
        if existing_user.lower() == requested_username.lower():
            return existing_user
    return None

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/auth', methods=['POST'])
def auth():
    data = request.json
    action = data.get('action')
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    
    if action == 'register':
        if not email:
            return jsonify({"success": False, "message": "Email required for signup."})
            
        # Check if the username exists (case-insensitive)
        if get_exact_username(username):
            return jsonify({"success": False, "message": "dont steal a username gng"})
        
        normalized_email = email.strip().lower()
        hashed_email = hashlib.sha256(normalized_email.encode()).hexdigest()
        
        if any(u.get('email') == hashed_email for u in users.values()):
            return jsonify({"success": False, "message": "Email is already registered."})
            
        user_id = str(uuid.uuid4())[:8]
        hashed_password = generate_password_hash(password)
        
        selected_pfp = data.get('pfp', 'pfp1.png')
        if selected_pfp not in ['pfp1.png', 'pfp2.png', 'pfp3.png']:
            selected_pfp = 'pfp1.png'
        
        users[username] = {
            "password": hashed_password, 
            "email": hashed_email, 
            "pfp": selected_pfp, 
            "display_name": username, 
            "id": user_id
        }
        save_users()
        return jsonify({
            "success": True, 
            "pfp": selected_pfp,
            "display_name": username,
            "id": user_id
        })
        
    else: 
        # Case-insensitive login
        actual_username = get_exact_username(username)
        if not actual_username:
            return jsonify({"success": False, "message": "User does not exist."})
            
        user = users[actual_username]
        if check_password_hash(user['password'], password):
            return jsonify({
                "success": True, 
                "pfp": user['pfp'],
                "display_name": user['display_name'],
                "id": user['id']
            })
        return jsonify({"success": False, "message": "Invalid password."})

@app.route('/api/settings', methods=['POST'])
def update_settings():
    data = request.json
    username = data.get('username')
    
    actual_username = get_exact_username(username)
    if not actual_username:
        return jsonify({"success": False, "message": "User not found."})
        
    if 'display_name' in data and data['display_name'].strip():
        users[actual_username]['display_name'] = data['display_name'].strip()
        
    if 'pfp' in data and data['pfp']:
        users[actual_username]['pfp'] = data['pfp']
        
    save_users()
    return jsonify({
        "success": True, 
        "display_name": users[actual_username]['display_name'],
        "pfp": users[actual_username]['pfp'],
        "id": users[actual_username]['id']
    })

@app.route('/api/user/<username>')
def get_user_profile(username):
    actual_username = get_exact_username(username)
    if not actual_username:
        return jsonify({"success": False, "message": "User not found."})
        
    user = users[actual_username]
    return jsonify({
        "success": True,
        "username": actual_username,
        "display_name": user['display_name'],
        "pfp": user['pfp'],
        "id": user['id']
    })

@app.route('/api/history/<room_id>')
def get_history(room_id):
    return jsonify(messages_db.get(room_id, []))

@socketio.on('send_message')
def handle_message(data):
    receiver = data.get('receiver')
    sender = data.get('sender')
    
    actual_sender = get_exact_username(sender)
    
    if actual_sender and actual_sender in users:
        user = users[actual_sender]
        data['pfp'] = user['pfp']
        data['display_name'] = user['display_name']
        data['user_id'] = user['id']
        data['sender'] = actual_sender # Normalize it for the frontend
    else:
        data['pfp'] = "🔵"
        data['display_name'] = sender
        data['user_id'] = "unknown"

    room = 'global' if receiver == 'global' else get_dm_room(data['sender'], receiver)
    data['room'] = room
    
    if 'content' in data:
        data['content'] = censor_text(data['content'])
    
    if room not in messages_db:
        messages_db[room] = []
    messages_db[room].append(data)
    
    emit('receive_message', data, broadcast=True)

# --- WEBRTC VOICE ROUTES ---

@socketio.on('join_voice')
def on_join_voice(data):
    sender = data.get('sender')
    actual_sender = get_exact_username(sender)
    
    user = users.get(actual_sender, {}) if actual_sender else {}
    display_name = user.get('display_name', sender)
    pfp = user.get('pfp', '🔵')
    
    emit('voice_user_joined', {
        'sid': request.sid, 
        'username': actual_sender or sender, 
        'display_name': display_name, 
        'pfp': pfp
    }, broadcast=True, include_self=False)
    
    current_users = [
        {'sid': sid, 'username': info['username'], 'display_name': info['display_name'], 'pfp': info['pfp']} 
        for sid, info in voice_users.items()
    ]
    
    voice_users[request.sid] = {'username': actual_sender or sender, 'display_name': display_name, 'pfp': pfp}
    return current_users

@socketio.on('voice_signal')
def on_voice_signal(data):
    target_sid = data.get('target_sid')
    if target_sid:
        emit('voice_signal', {'sender_sid': request.sid, 'signal': data.get('signal')}, to=target_sid)

@socketio.on('leave_voice')
def on_leave_voice():
    if request.sid in voice_users:
        del voice_users[request.sid]
        emit('voice_user_left', {'sid': request.sid}, broadcast=True)

@socketio.on('disconnect')
def handle_disconnect():
    if request.sid in voice_users:
        del voice_users[request.sid]
        emit('voice_user_left', {'sid': request.sid}, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5000)