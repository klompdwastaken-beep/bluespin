import os
import json
import hashlib
from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
import re
import uuid
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, static_folder='.', static_url_path='')
app.config['SECRET_KEY'] = 'secret!'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024 
socketio = SocketIO(app, cors_allowed_origins="*")

USERS_FILE = 'users.json'

def load_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_users():
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

users = load_users()
messages_db = {"global": []} 

BAD_WORDS = ["fuck", "shit", "bitch", "ass", "crap", "damn"] 

def censor_text(text):
    if not text:
        return text
    for word in BAD_WORDS:
        pattern = re.compile(re.escape(word), re.IGNORECASE)
        text = pattern.sub(lambda m: '*' * len(m.group()), text)
    return text

def get_dm_room(u1, u2):
    return "dm_" + "_".join(sorted([u1, u2]))

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/auth', methods=['POST'])
def auth():
    data = request.json
    action = data.get('action')
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    
    if action == 'register':
        if not email:
            return jsonify({"success": False, "message": "Email required for signup."})
        if username in users:
            return jsonify({"success": False, "message": "Username is already taken."})
        
        # Normalize and hash the email using SHA-256
        normalized_email = email.strip().lower()
        hashed_email = hashlib.sha256(normalized_email.encode()).hexdigest()
        
        # Check if the hashed email is already in the database
        if any(u.get('email') == hashed_email for u in users.values()):
            return jsonify({"success": False, "message": "Email is already registered."})
            
        user_id = str(uuid.uuid4())[:8]
        hashed_password = generate_password_hash(password)
        
        # Grab the chosen PFP, fallback to pfp1.png if invalid
        selected_pfp = data.get('pfp', 'pfp1.png')
        if selected_pfp not in ['pfp1.png', 'pfp2.png', 'pfp3.png']:
            selected_pfp = 'pfp1.png'
        
        users[username] = {
            "password": hashed_password, 
            "email": hashed_email,  # Saved as a hash now!
            "pfp": selected_pfp, 
            "display_name": username, 
            "id": user_id
        }
        save_users()
        return jsonify({
            "success": True, 
            "pfp": selected_pfp,
            "display_name": username,
            "id": user_id
        })
        
    else: 
        if username not in users:
            return jsonify({"success": False, "message": "User does not exist."})
            
        user = users[username]
        if check_password_hash(user['password'], password):
            return jsonify({
                "success": True, 
                "pfp": user['pfp'],
                "display_name": user['display_name'],
                "id": user['id']
            })
        return jsonify({"success": False, "message": "Invalid password."})

@app.route('/api/settings', methods=['POST'])
def update_settings():
    data = request.json
    username = data.get('username')
    
    if username not in users:
        return jsonify({"success": False, "message": "User not found."})
        
    if 'display_name' in data and data['display_name'].strip():
        users[username]['display_name'] = data['display_name'].strip()
        
    if 'pfp' in data and data['pfp']:
        users[username]['pfp'] = data['pfp']
        
    save_users()
    return jsonify({
        "success": True, 
        "display_name": users[username]['display_name'],
        "pfp": users[username]['pfp'],
        "id": users[username]['id']
    })

@app.route('/api/user/<username>')
def get_user_profile(username):
    user = users.get(username)
    if not user:
        return jsonify({"success": False, "message": "User not found."})
        
    return jsonify({
        "success": True,
        "username": username,
        "display_name": user['display_name'],
        "pfp": user['pfp'],
        "id": user['id']
    })

@app.route('/api/history/<room_id>')
def get_history(room_id):
    return jsonify(messages_db.get(room_id, []))

@socketio.on('send_message')
def handle_message(data):
    receiver = data.get('receiver')
    sender = data.get('sender')
    
    user = users.get(sender)
    if user:
        data['pfp'] = user['pfp']
        data['display_name'] = user['display_name']
        data['user_id'] = user['id']
    else:
        data['pfp'] = "🔵"
        data['display_name'] = sender
        data['user_id'] = "unknown"

    room = 'global' if receiver == 'global' else get_dm_room(sender, receiver)
    data['room'] = room
    
    if 'content' in data:
        data['content'] = censor_text(data['content'])
    
    if room not in messages_db:
        messages_db[room] = []
    messages_db[room].append(data)
    
    emit('receive_message', data, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5000)